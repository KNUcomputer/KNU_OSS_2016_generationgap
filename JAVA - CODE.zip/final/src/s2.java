import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

class s2 extends JPanel{     	

    private JPanelTest win;
    private JTextField error;
    int cnt=0, cnt2=0;
    int x, y, i=0;
    private int[][] arr = {{101,313},{74,347},{63,368},{95,412},{171,403},{223,390},{235,325},{243,264},
    		{294,168},{317,136},{349,127},{435,82},{420,31},{394,17},{431,140},{433,187}};
	
    public s2(JPanelTest win){
        
    	this.win = win;
        
        setLayout(null);
       
        
        ImageIcon img;
        
        img = new ImageIcon("s2.jpg");
        
        final JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
	    
        add(label);

	this.addMouseListener( 
                
                new MouseAdapter() 
                {
                   public void mousePressed( MouseEvent event ) 
                   {
                     int  x = event.getX(); // get x position of mouse press
                     int y = event.getY(); // get y position of mouse press
                      
                      
/*                  	System.out.printf("x�� ��ǥ : %d y�� ��ǥ : %d \n", x, y);*/
                  
                  	if((x < arr[i][0]+20 && x > arr[i][0]-20 ) && (y < arr[i][1]+20 && y > arr[i][1]-20) && i == cnt)
                	{
                		cnt++; 
                		i++;
                	
                		if(cnt2 != 0 && i ==1 )
                		{
                			error.setVisible(false);
                		}
                		if(cnt == 16)
                		{
                			if(cnt2 != 0){
	                			error.setVisible(false);
	                		}
                			label.setVisible(false);
                			 
                			ImageIcon img2;
                			
                	        img2 = new ImageIcon("s2_2.jpg");
                	        
                	        JLabel label2 = new JLabel(img2);  
                	        
                	        label2 = new JLabel(img2);
                	        
                	        label2.setBounds(0,0,img2.getIconWidth(), img2.getIconHeight());
                			
                		    setLayout(new FlowLayout()); 
                		    
                	        add(label2);
                	        
                	        if(cnt2 != 0){
	                			error.setVisible(false);
	                		}
                			i=0;
                		}
                		System.out.printf("cnt : %d\n", cnt);
                	}
                  	else if (cnt == 16){
                  		
                  	}
                  	else 
                	{
                        error = new JTextField("�ٽ� �ѹ� �غ����?!");
                      
                        error.setSize(150,40);        
                        error.setLocation(60, 60);
                        add(error);
                        i=0;
                        cnt=0;
                        cnt2++;
                		
                	}
                   }
                });
        
   
    }
    
    
}