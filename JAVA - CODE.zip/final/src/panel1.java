import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.IOException;

import javax.swing.*;

import com.leapmotion.leap.Controller;


class Panel1 extends JPanel {  // 1��° �г�

    private JTextArea jTextArea1;
    private JPanelTest win;
	
    public Panel1(final JPanelTest win){
        
    	this.win = win;
    	this.win.check = 1;
    	
        setLayout(null);
        
        
        ImageIcon img;
        
        img = new ImageIcon("main.jpg");
        
        JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
        add(label);  
        

        
        this.addMouseListener( 
                
                new MouseAdapter() 
                {
                   public void mousePressed( MouseEvent event ) 
                   {
                      int x = event.getX(); // get x position of mouse press
                      int y = event.getY(); // get y position of mouse press
                      
                      if(x > 80 && x< 220 && y > 230 && y < 380)
                      {
                    	  win.change("panel2");
                      }
                      else  if(x > 300 && x< 415 && y > 230 && y < 380)
                      {
                    	  System.exit(0);
                      }

                  	
                   }
                });
  

   
    }
    
  
}


