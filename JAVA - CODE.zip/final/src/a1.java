import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;

import com.leapmotion.leap.Controller;

class a1 extends JPanel { // 2��° �г�

	private JPanelTest win;
	private JTextField field;
	private int[][] a1Arr = { { 129, 403 }, { 486, 303 }, { 471, 273 }, { 400, 247 }, { 418, 111 }, { 316, 32 },
			{ 295, 66 } };
	int cnt = 0, cnt2 = 0;
	int x, y;
	int i = 0;
	JTextField error;

	public a1(JPanelTest win) {

		this.win = win;

		setLayout(null);

		ImageIcon img;

		img = new ImageIcon("a1.jpg");

		final JLabel label = new JLabel(img);

		label.setBounds(0, 0, img.getIconWidth(), img.getIconHeight());

		setLayout(new FlowLayout());

		add(label);

		this.addMouseListener(

				new MouseAdapter() {
					public void mousePressed(MouseEvent event) {
						x = event.getX(); // get x position of mouse press
						y = event.getY(); // get y position of mouse press

/*						System.out.printf("{%d, %d}, ", x, y);
						System.out.printf("i: %d", i);*/

						if ((x < a1Arr[i][0] + 25 && x > a1Arr[i][0] - 25)
								&& (y < a1Arr[i][1] + 25 && y > a1Arr[i][1] - 25) && i == cnt) {
							cnt++;
							i++;

							if (cnt2 != 0 && i == 1) {
								error.setVisible(false);
							}
							if (cnt == 7) {
								
								if(cnt2 != 0){
		                			error.setVisible(false);
		                		}
								label.setVisible(false);
								
								ImageIcon img2;

								img2 = new ImageIcon("a1_2.jpg");

								JLabel label2 = new JLabel(img2);

								label2 = new JLabel(img2);

								label2.setBounds(0, 0, img2.getIconWidth(), img2.getIconHeight());

								setLayout(new FlowLayout());

								add(label2);

								if(cnt2!=0){
	                   				
	                    			error.setVisible(false);
	                    			}
								i = 0;
							}
							System.out.printf("cnt : %d\n", cnt);
						} 
						else if (cnt == 14) {

						}

				else {
							error = new JTextField("�ٽ� �ѹ� �غ����?!");

							error.setSize(150, 40);
							error.setLocation(60, 230);
							add(error);
							i = 0;
							cnt = 0;
							cnt2++;

						}

					} // end method mousePressed
				} // end anonymous inner class
		);

	}

}