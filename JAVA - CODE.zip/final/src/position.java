import javax.swing.ImageIcon;
import javax.swing.JFrame;

public class position
{
   private int x; // horizontal position of ball
   private int y; // vertical position of ball
   private int dx; // change in horizontal position of ball
   private int dy; // change in vertical position of ball
   private final int MAX_X = 200; // horizontal edge of JPanel
   private final int MAX_Y = 200; // vertical edge of JPanel

   public position( ImageIcon ic )
   {
	  
   }
   
   public position( int xPos, int yPos )
   {

      x = xPos; // set ball to horizontal position of mouse press
      y = yPos; // set ball to vertical position of mouse press
      
 //    System.out.printf("x�� ��ǥ�� :%d  y�� ��ǥ�� :%d", x, y);
  
   }

   public int getX()
   {
      return x; // return x value
   } // end method getX

   // get vertical position of ball
   public int getY()
   {
      return y; // return y value
   } // end method getY
} // end class Ball
