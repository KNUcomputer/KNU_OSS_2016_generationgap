import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


class Panel2 extends JPanel{     	// 2��° �г�
   
    private JPanelTest win;


    public Panel2(JPanelTest win){
        
    	this.win = win;

  	
        setLayout(null);

        
        ImageIcon img;
        
        img = new ImageIcon("menu.jpg");
        
        JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
        add(label);
        
        
        
   
    }
    

}

