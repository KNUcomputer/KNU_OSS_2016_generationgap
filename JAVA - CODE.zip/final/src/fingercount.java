import java.io.IOException;
import com.leapmotion.leap.*;
import com.leapmotion.leap.Gesture.State;


public class fingercount extends Listener {

   int circleStart = 0;
   int circleStop = 0;
   int swipeStart = 0;
    int swipeStop = 0;
    int number = 0;
    
    JPanelTest win = new JPanelTest();
    
   public fingercount(JPanelTest win)
   {
	   this.win=win;

	   
   }
   public void onInit(Controller controller) {
      System.out.println("Initialized");
   }

   public void onConnect(Controller controller) {
      System.out.println("Connected to Motion Sensor");
      
      controller.enableGesture(Gesture.Type.TYPE_SWIPE);
      controller.enableGesture(Gesture.Type.TYPE_CIRCLE);
      controller.enableGesture(Gesture.Type.TYPE_SCREEN_TAP);
      controller.enableGesture(Gesture.Type.TYPE_KEY_TAP);

   }

   public void onDisconnect(Controller controller) {
      System.out.println("Motion Sensor Disconnected");
   }

   public void onExit(Controller controller) {
      System.out.println("Exited");
   }

   public void onFrame(Controller controller) {

      Frame frame = controller.frame();

 //     System.out.println("\nFinger count:  " + frame.fingers().extended().count());
      
      if(frame.fingers().extended().count() == 1)
      {
    	  number=1;
    	  win.change("spring");
      }
      else if(frame.fingers().extended().count() == 2)
      {
    	  number=2;
    	  win.change("summer");
      }
      else if(frame.fingers().extended().count() == 3)
      {
    	  number=3;
    	  win.change("autumn");
      }
      else if(frame.fingers().extended().count() == 4)
      {
    	  number=4;
    	  win.change("winter");
      }

   }
}

