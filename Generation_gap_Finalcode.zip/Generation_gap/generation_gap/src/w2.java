import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


class w2 extends JPanel{     	// 2��° �г�
   
    private JPanelTest win;
    private JTextField field;
    private int[][] w2Arr ={{86, 387}, {162, 384}, {170, 241}, {157, 167}, 
    		{69, 223}, {210, 16}, {296, 24}, {312, 119}, 
    		{412, 148}, {288, 269}, {296, 373}, {317, 399}, {355, 430}};
    int cnt = 0, cnt2 = 0;
    int x, y;
    int i=0;
    JTextField error;
	
    public w2(JPanelTest win){
        
    	this.win = win;
        
        setLayout(null);
        
        ImageIcon img;
        
        img = new ImageIcon("w2.jpg");
        
        final JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
	    
        add(label);

this.addMouseListener( 
                
                new MouseAdapter() 
                {
                   public void mousePressed( MouseEvent event ) 
                   {
                      x = event.getX(); // get x position of mouse press
                      y = event.getY(); // get y position of mouse press
                      
                  	

                  	if((x < w2Arr[i][0]+20 && x > w2Arr[i][0]-20 ) && (y < w2Arr[i][1]+20 && y > w2Arr[i][1]-20) && i == cnt)
                	{
                		cnt++; 
                		i++;
                	
                		if(cnt2 != 0 && i ==1 )
                		{
                			error.setVisible(false);
                		}
                		if(cnt == 13)
                		{
	
                			if(cnt2 != 0){
	                			error.setVisible(false);
	                		}
                			label.setVisible(false);
                			
                			ImageIcon img2;
                			
                	        img2 = new ImageIcon("w2_2.jpg");
                	        
                	        JLabel label2 = new JLabel(img2);  
                	        
                	        label2 = new JLabel(img2);
                	        
                	        label2.setBounds(0,0,img2.getIconWidth(), img2.getIconHeight());
                			
                		    setLayout(new FlowLayout()); 
                		    
                	        add(label2);
                	        
                	        if(cnt2 != 0){
	                			error.setVisible(false);
	                		}
                			i=0;
                		}
                		System.out.printf("cnt : %d\n", cnt);
                	}
                  	else if (cnt == 13){
                  		
                  	}
                  	else 
                	{
                        error = new JTextField("�ٽ� �ѹ� �غ����?!");
                      
                        error.setSize(150,40);        
                        error.setLocation(2, 62);
                        add(error);
                        i=0;
                        cnt=0;
                        cnt2++;
                       
                		
                	}
                      
                   } // end method mousePressed
                } // end anonymous inner class
             );
   
    }
    
    class MyActionListener implements ActionListener
    {         // ��ư Ű ������ �г� 1�� ȣ��
        
    	@Override
        public void actionPerformed(ActionEvent e) 
        {
        	String event = e.getActionCommand();
        	
        	if(event == "����")
        	{
        		win.change("w3");
        	}

        }
    }
}