import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


class winter extends JPanel{     	// 2��° �г�
   

    private JPanelTest win;

    public winter(final JPanelTest win){
        
    	this.win = win;
        
        setLayout(null);

        ImageIcon img;
        
        img = new ImageIcon("winter.jpg");
        
        JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
	    
		add(label);

		this.addMouseListener(

				new MouseAdapter() {
					public void mousePressed(MouseEvent event) {
						int x = event.getX(); // get x position of mouse press
						int y = event.getY(); // get y position of mouse press

						if (x > 140 && x < 309 && y > 23 && y < 68) {
							win.change("w1");
						} else if (x > 135 && x < 420 && y > 157 && y < 210) {
							win.change("w2");
						} else if (x > 136 && x < 368 && y > 284 && y < 343) {
							win.change("w3");

						}

					}
				});
   
    }
    
    class MyActionListener implements ActionListener
    {         // ��ư Ű ������ �г� 1�� ȣ��
        @Override
        public void actionPerformed(ActionEvent e) {
        	String event = e.getActionCommand();
        	
        	if(event == "��")
        	{
        		win.change("w1");
        	}
        	else if(event == "�ֵ���")
        	{
        		win.change("w2");
        	}
        	else if(event == "Ȳ��")
        	{
        		win.change("w3");
        	}

        }
    }
}

