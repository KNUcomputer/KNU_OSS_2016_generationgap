import com.leapmotion.leap.*;
import com.leapmotion.leap.Gesture.State;
import com.leapmotion.leap.Gesture.Type;

import java.awt.Dimension;
import java.awt.Robot;
import java.awt.event.InputEvent;
import java.awt.event.KeyEvent;

class MouseControl extends Listener {

   public Robot robot;

   public void onConnect(Controller c) {
      c.enableGesture(Gesture.Type.TYPE_CIRCLE);
      c.enableGesture(Gesture.Type.TYPE_SCREEN_TAP);
      c.enableGesture(Gesture.Type.TYPE_SWIPE);
      c.enableGesture(Gesture.Type.TYPE_KEY_TAP);
   }

   public void onFrame(Controller c) {
      try {
         robot = new Robot();
      } catch (Exception e) {
      }
     
      Frame frame = c.frame();
      InteractionBox box = frame.interactionBox();
     
     /* make Mouse controller by finger frame */
      
      for (Finger f : frame.fingers()) { // Forefinger 
         for (Finger t : frame.fingers()) { // Thumb
            for (Finger p : frame.fingers()) { // Pinky
               for (Finger m : frame.fingers()) { // Middle
                  for (Finger r : frame.fingers()) { // Ring

       /* if all finger frames correspond each finger */
                	  
                     if (f.type() == Finger.Type.TYPE_INDEX) {        
                        if (t.type() == Finger.Type.TYPE_THUMB) {
                           if (p.type() == Finger.Type.TYPE_PINKY) {
                              if (m.type() == Finger.Type.TYPE_MIDDLE) {
                                 if (r.type() == Finger.Type.TYPE_RING) {

                                    Vector indexPos = f
                                          .stabilizedTipPosition();
                                    Vector thumbPos = t
                                          .stabilizedTipPosition();
                                    Vector middlePos = p
                                          .stabilizedTipPosition();

                                    Vector notTouching1 = new Vector(
                                          20, 20, 20);
                                    Vector notTouching2 = new Vector(
                                          -20, -20, -20);
         
                                    float leftClickX = indexPos
                                          .get(0)
                                          - thumbPos.get(0);
                                    float leftClickY = indexPos
                                          .get(1)
                                          - thumbPos.get(1);
                                    float leftClickZ = indexPos
                                          .get(2)
                                          - thumbPos.get(2); // 

                                    float rightClickX = middlePos
                                          .get(0)
                                          - thumbPos.get(0);
                                    float rightClickY = middlePos
                                          .get(1)
                                          - thumbPos.get(1);
                                    float rightClickZ = middlePos
                                          .get(2)
                                          - thumbPos.get(2);

                                    Vector leftClick = new Vector(
                                          leftClickX, leftClickY,
                                          leftClickZ);
                                    Vector rightClick = new Vector(
                                          rightClickX,
                                          rightClickY,
                                          rightClickZ);

                                   
                                    if (f.isExtended()
                                          && m.isExtended()
                                          && r.isExtended()
                                          && p.isExtended()) 
                                    {
                                       for (Hand h : frame.hands()) {
                                          Vector handPos = h
                                                .palmPosition();
                                          Vector boxHandPos = box
                                                .normalizePoint(handPos);
                                          Dimension screen = java.awt.Toolkit
                                                .getDefaultToolkit()
                                                .getScreenSize();
                                          robot.mouseMove(
                                                (int) (screen.width * boxHandPos
                                                      .getX()),
                                                (int) (screen.height - boxHandPos
                                                      .getY()
                                                      * screen.height));
                                       }
                                    } // if 4 fingers are extended and hand is moved, mouse cursor is moved.

                                    for (Gesture g : frame
                                          .gestures()) {
                                       if (g.type() == Type.TYPE_KEY_TAP) {
                                          if (f.isExtended()
                                                && m.isExtended()) { 
                                             robot.mousePress(InputEvent.BUTTON1_DOWN_MASK); // down scroll motion
                                             try {
                                                Thread.sleep(50);
                                             } catch (Exception e) {
                                             }
                                             robot.mouseRelease(InputEvent.BUTTON1_MASK);

                                          }

                                       }
                                      
                                    }
                                 }
                              }
                           }
                        }

                     }
                  }
               }
            }
         }
      }
   }
}