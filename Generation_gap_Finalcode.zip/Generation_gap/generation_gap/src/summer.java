import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


class summer extends JPanel{     	// 2��° �г�
  
    private JPanelTest win;
	
    public summer(final JPanelTest win){
        
    	this.win = win;
        
        setLayout(null);
        
        ImageIcon img;
        
        img = new ImageIcon("summer.jpg");
        
        JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
	    
        add(label);
        
        
        this.addMouseListener( 
                
                new MouseAdapter() 
                {
                   public void mousePressed( MouseEvent event ) 
                   {
                      int x = event.getX(); // get x position of mouse press
                      int y = event.getY(); // get y position of mouse press   
                  	
                  	if(x > 140 && x < 370 && y > 23 && y < 68) //����ڸ��� ��
                  	{
                  		win.change("s1");
                  	}
                  	else if(x > 140 && x < 370 && y > 150 && y < 240)
                  	{
                  		win.change("s2");
                  	}
                  	else if(x > 140 && x < 370 && y > 280 && y < 340)
                  	{
                  		win.change("s3");
                  	}
                      
                   } // end method mousePressed
                } // end anonymous inner class
             );

    }
    
   
}

