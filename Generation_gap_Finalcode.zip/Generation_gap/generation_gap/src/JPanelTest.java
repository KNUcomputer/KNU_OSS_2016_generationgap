import java.awt.Component;
import java.awt.Dimension;
import java.awt.Toolkit;
import java.io.IOException;

import javax.swing.JFrame;

import com.leapmotion.leap.Controller;

class JPanelTest extends JFrame{ //Making mainframe by using Jframe.
    
    public Panel1 jpanel01 = null;
    public Panel2 jpanel02 = null;
    public spring springpanel = null; 
    public summer summerpanel = null;
    public autumn autumnpanel = null;
    public winter winterpanel = null;
    public sp1 sp1panel = null;
    public sp2 sp2panel = null;
    public s1 s1panel = null;
    public s2 s2panel = null;
    public s3 s3panel = null;
    public w1 w1panel = null;
    public w2 w2panel = null;
    public w3 w3panel = null;
    public a1 a1panel = null;
    public a2 a2panel = null;
    public a3 a3panel = null;
    public a4 a4panel = null;
    public int check;


    public void change(String panelName){  
    // Panel change method - every panel changing is available.
       
        if(panelName.equals("panel2"))
        {
            getContentPane().removeAll();
            getContentPane().add(jpanel02);
            revalidate();
            repaint();
  
        }
        else if(panelName.equals("spring"))
        {
            getContentPane().removeAll();
            getContentPane().add(springpanel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("summer"))
        {
            getContentPane().removeAll();
            getContentPane().add(summerpanel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("autumn"))
        {
            getContentPane().removeAll();
            getContentPane().add(autumnpanel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("winter"))
        {
            getContentPane().removeAll();
            getContentPane().add(winterpanel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("sp1"))
        {
            getContentPane().removeAll();
            getContentPane().add(sp1panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("sp2"))
        {
            getContentPane().removeAll();
            getContentPane().add(sp2panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("s1"))
        {
            getContentPane().removeAll();
            getContentPane().add(s1panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("s2"))
        {
            getContentPane().removeAll();
            getContentPane().add(s2panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("s3"))
        {
            getContentPane().removeAll();
            getContentPane().add(s3panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("w1"))
        {
            getContentPane().removeAll();
            getContentPane().add(w1panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("w2"))
        {
            getContentPane().removeAll();
            getContentPane().add(w2panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("w3"))
        {
            getContentPane().removeAll();
            getContentPane().add(w3panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("a1"))
        {
            getContentPane().removeAll();
            getContentPane().add(a1panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("a2"))
        {
            getContentPane().removeAll();
            getContentPane().add(a2panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("a3"))
        {
            getContentPane().removeAll();
            getContentPane().add(a3panel);
            revalidate();
            repaint();
        }
        else if(panelName.equals("a4"))
        {
            getContentPane().removeAll();
            getContentPane().add(a4panel);
            revalidate();
            repaint();
        }

        		
    }
    
    public static void main(String[] args) { // main code
         
       JPanelTest win = new JPanelTest();
    		   
        win.setTitle("���ڸ� �������α׷�"); 
        
        // making every panel 
        
        win.jpanel01 = new Panel1(win);
        win.jpanel02 = new Panel2(win);
        win.springpanel = new spring(win);
        win.summerpanel = new summer(win);
        win.autumnpanel = new autumn(win);
        win.winterpanel = new winter(win);
        win.sp1panel = new sp1(win);
        win.sp2panel = new sp2(win);
        win.s1panel = new s1(win);
        win.s2panel = new s2(win);
        win.s3panel = new s3(win);
        win.a1panel = new a1(win);
        win.a2panel = new a2(win);
        win.a3panel = new a3(win);
        win.a4panel = new a4(win);
        win.w1panel = new w1(win);
        win.w2panel = new w2(win);
        win.w3panel = new w3(win);
             
                
        win.add(win.jpanel01); // first frame image

        
        win.setSize(550,490); // set framesize
              
        win.setVisible(true);  
        
        
        
        /* interlocking leapmotion and GUI.  */
        
        GestureListener g = new GestureListener(win);
       
        Controller controller = new Controller();
        
        MouseControl listener = new MouseControl();
        
        controller.addListener(g);
        controller.addListener(listener);
        
        try 
        {
           System.in.read();
        } 
        catch (IOException e) 
        {
           e.printStackTrace();
        }
        
        
        try {
        
        	System.in.read();
            
         } 
        catch (IOException e) {

            e.printStackTrace();
         }
        
        controller.removeListener(listener);
        controller.removeListener(g);

    }
}