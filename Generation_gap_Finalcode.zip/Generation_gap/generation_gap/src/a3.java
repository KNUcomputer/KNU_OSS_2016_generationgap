import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


class a3 extends JPanel{     	// 2��° �г�
   

    private JPanelTest win;
    private JTextField field;
    private int[][] a3Arr ={{509, 172}, {428, 126}, {324, 95}, {282, 121}, 
    		{313, 182}, {360, 242}, {259, 113}, {263, 93}, 
    		{242, 117}, {223, 210}, {247, 272}, {247, 300}, 
    		{228, 371}, {189, 373}, {131, 365}, {112, 330}, {158, 213}};
    int cnt = 0, cnt2 = 0;
    int x, y;
    int i=0;
    JTextField error;
	
    public a3(JPanelTest win){
        
    	this.win = win;
        
        setLayout(null);

        ImageIcon img;
        
        img = new ImageIcon("a3.jpg");
        
        final JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
	    
        add(label);
        
this.addMouseListener( 
                
                new MouseAdapter() 
                {
                   public void mousePressed( MouseEvent event ) 
                   {
                      x = event.getX(); // get x position of mouse press
                      y = event.getY(); // get y position of mouse press
                        	

                  	if((x < a3Arr[i][0]+20 && x > a3Arr[i][0]-20 ) && (y < a3Arr[i][1]+20 && y > a3Arr[i][1]-20) && i == cnt)
                	{
                		cnt++; 
                		i++;
                	
                		if(cnt2 != 0 && i ==1 )
                		{
                			error.setVisible(false);
                		}
                		if(cnt == 17)
                		{
	
                			if(cnt2 != 0){
	                			error.setVisible(false);
	                		}
                			label.setVisible(false);
                			
                			ImageIcon img2;
                			
                	        img2 = new ImageIcon("a3_2.jpg");
                	        
                	        JLabel label2 = new JLabel(img2);  
                	        
                	        label2 = new JLabel(img2);
                	        
                	        label2.setBounds(0,0,img2.getIconWidth(), img2.getIconHeight());
                			
                		    setLayout(new FlowLayout()); 
                		    
                	        add(label2);
                	        
                	        if(cnt2 != 0){
	                			error.setVisible(false);
	                		}
                			i=0;
                		}
                		System.out.printf("cnt : %d\n", cnt);
                	}
                  	else if (cnt == 17){
                  		
                  	}
                  	else 
                	{
                        error = new JTextField("�ٽ� �ѹ� �غ����?!");
                      
                        error.setSize(150,40);        
                        error.setLocation(378, 371);
                        add(error);
                        i=0;
                        cnt=0;
                        cnt2++;
                		
                	}
                      
                   } // end method mousePressed
                } // end anonymous inner class
             );
   
    }
    
    class MyActionListener implements ActionListener
    {         // ��ư Ű ������ �г� 1�� ȣ��
        
    	@Override
        public void actionPerformed(ActionEvent e) 
        {
        	String event = e.getActionCommand();
        	
        	if(event == "����")
        	{
        		win.change("a4");
        	}

        }
    }
}