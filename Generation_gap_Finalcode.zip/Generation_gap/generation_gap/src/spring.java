import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


class spring extends JPanel{     	// 2��° �г�

    private JPanelTest win;
    
    public spring(final JPanelTest win){
        
    	this.win = win;
        
        setLayout(null);
            
        ImageIcon img;
        
        img = new ImageIcon("spring.jpg");
        
        JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
	    
        add(label);
        
        this.addMouseListener( 
                
                new MouseAdapter() 
                {
                   public void mousePressed( MouseEvent event ) 
                   {
                      int x = event.getX(); // get x position of mouse press
                      int y = event.getY(); // get y position of mouse press
                     
                      
                      if(x > 130 && x< 395 && y > 70 && y < 150) 
                      {
                    	  win.change("sp1");
                      }
                      else if(x > 125 && x < 390 && y > 210 && y < 280)
                      {
                    	   win.change("sp2");
                      }
     	
                   }
                });
  
        
  
        
   
    }
   
}

