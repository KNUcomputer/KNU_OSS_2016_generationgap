import java.awt.FlowLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JPasswordField;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;


class sp1 extends JPanel{     	// 2��° �г�
   

    private JPanelTest win;
    private JTextField field;
    int i=0; 
    int cnt =0,cnt2=0;
    JTextField error;
    private int[][] arr ={{421, 244}, {396, 224}, {352, 258}, {348, 296},
            {226, 302}, {149, 369}, {231, 353}, {391, 367},  
            {384, 319}, {459, 375}, {481, 354}, {260, 169}, 
            {306, 139}, {349, 145}};

    
    public sp1(JPanelTest win){
        
    	this.win = win;
        
        setLayout(null);
        
        ImageIcon img;
        
        img = new ImageIcon("sp1.jpg");
        
        final JLabel label = new JLabel(img);   

		label.setBounds(0,0,img.getIconWidth(), img.getIconHeight());
		
	    setLayout(new FlowLayout()); 
	    
        add(label);
       
        this.addMouseListener( 
                
                new MouseAdapter() 
                {
                   public void mousePressed( MouseEvent event ) 
                   {
                     int  x = event.getX(); // get x position of mouse press
                     int y = event.getY(); // get y position of mouse press
                      
                      
                  	if((x < arr[i][0]+20 && x > arr[i][0]-20 ) && (y < arr[i][1]+20 && y > arr[i][1]-20) && i == cnt)
                	{

                		cnt++; 
                		i++;
                	
                		if(cnt2 != 0 && i ==1 ) 
                		{
                			error.setVisible(false);
                		}
                		if(cnt == 14)
                		{
	
                			if(cnt2 != 0){
	                			error.setVisible(false);
	                		}
                			label.setVisible(false);
                			
                			ImageIcon img2;
                			
                	        img2 = new ImageIcon("sp1_2.jpg");
                	        
                	        JLabel label2 = new JLabel(img2);  
                	        
                	        label2 = new JLabel(img2);
                	        
                	        label2.setBounds(0,0,img2.getIconWidth(), img2.getIconHeight());
                			
                		    setLayout(new FlowLayout()); 
                		    
                	        add(label2);
                	        
                	        if(cnt2 != 0){
	                			error.setVisible(false);
	                		}
                			i=0;
                		}
                		System.out.printf("cnt : %d\n", cnt);
                	}
                  	else if (cnt == 14){
                  		
                  	}
                  	else 
                	{
                        error = new JTextField("�ٽ� �ѹ� �غ����?!");
                      
                        error.setSize(150,40);        
                        error.setLocation(60, 60);
                        add(error);
                        i=0;
                        cnt=0;
                        cnt2++;
                        
                		
                	}
                  	
                  	
                      
                   } // end method mousePressed
                } // end anonymous inner class
             );

    }
   
    
    
}